# Sitio web de Oscar Bonilla

Sitio personal profesional de una sola página, adaptable a móviles y escritorio.

## Vista previa local
1. Descomprimí el ZIP.
2. Abrí `index.html` en un navegador.
3. La tipografía usa Google Fonts y requiere conexión a internet; el resto de estilos está integrado.

## Antes de publicar
- Sustituir el monograma OB por una fotografía profesional o logotipo definitivo si se desea.
- Confirmar las denominaciones exactas de los títulos académicos y credenciales.
- Agregar correo profesional en la variable `destination` del script al final de `index.html`.
- Agregar enlaces oficiales de LinkedIn y otras redes si corresponde.
- Reemplazar las referencias textuales de organizaciones por logos oficiales autorizados, si se cuenta con los archivos.
- Revisar el texto de experiencia y las referencias institucionales para que reflejen exactamente la naturaleza de cada vínculo.
- Para recibir formularios sin que la persona abra su aplicación de correo, conectar un servicio de formularios o backend.
- Configurar dominio, alojamiento, HTTPS, analítica y Search Console antes del lanzamiento.

## Publicación
Este paquete contiene los archivos del sitio, pero no publica por sí solo el sitio en un dominio público. Puede alojarse en un servicio de hosting estático o en un servidor web.
